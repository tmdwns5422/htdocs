<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Signup</title>
    <link rel="stylesheet" href="./css/bootstrap.min.css">
    <link rel="stylesheet" href="./css/jquery-ui.min.css">
    <link rel="stylesheet" href="./css/signup.css">
</head>
<body>
<?php
    include "./app/page/header.php";
?>

    <div class="content">
        <section>
            
        </section>
    </div>
<?php
    include "./app/page/footer.php";
?>