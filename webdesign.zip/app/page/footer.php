        <footer>
            <div class="container">
                <p>&copy;SDHS &nbsp;&nbsp;&nbsp;Contact &amp;Map &nbsp; &nbsp; &nbsp; http://www.sdh.hs.kr/index/intro.do/SDHS &nbsp; &nbsp; &nbsp; dongsscc&#64;naver.com</p>
            </div>
        </footer>
            </div>
    <script src="js/jquery.js"></script>
    <script src="js/jquery-ui.min.js"></script>
    <script src="js/script.js"></script>
    <script src="js/sub_school.js"></script>
</body>
</html>