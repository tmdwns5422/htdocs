<?php
    include "./app/page/header.php";
?>
            <div class="content">
                <section id="welcome">
                   <div class="container">
                        <h1>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sequi, repellendus.</h1>
                    </div>
                </section>
                <section id="face">
                    <ul>
                        <li></li>
                        <li></li>
                        <li></li>
                        <li></li>
                    </ul>
                </section>
            </div>
        </div>
<?php
    include "./app/page/footer.php";
?>
