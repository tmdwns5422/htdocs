<?php
    session_start();
    $pdo= new PDO('mysql:host=127.0.0.1;dbname=kcc;charset=utf8','root','');
?>